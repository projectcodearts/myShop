import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-with-otp',
  templateUrl: './verify-with-otp.page.html',
  styleUrls: ['./verify-with-otp.page.scss'],
})
export class VerifyWithOtpPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
