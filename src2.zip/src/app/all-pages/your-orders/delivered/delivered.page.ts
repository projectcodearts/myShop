import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivered',
  templateUrl: './delivered.page.html',
  styleUrls: ['./delivered.page.scss'],
})
export class DeliveredPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
