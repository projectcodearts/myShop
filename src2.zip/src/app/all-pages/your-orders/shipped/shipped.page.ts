import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipped',
  templateUrl: './shipped.page.html',
  styleUrls: ['./shipped.page.scss'],
})
export class ShippedPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
