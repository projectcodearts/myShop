import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reset-pass-message',
  templateUrl: './reset-pass-message.page.html',
  styleUrls: ['./reset-pass-message.page.scss'],
})
export class ResetPassMessagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
