import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-with-otp-content',
  templateUrl: './verify-with-otp-content.component.html',
  styleUrls: ['./verify-with-otp-content.component.scss'],
})
export class VerifyWithOtpContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
