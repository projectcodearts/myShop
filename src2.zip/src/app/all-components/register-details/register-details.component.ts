import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-details',
  templateUrl: './register-details.component.html',
  styleUrls: ['./register-details.component.scss'],
})
export class RegisterDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
