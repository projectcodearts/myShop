import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-latest-checkout',
  templateUrl: './latest-checkout.component.html',
  styleUrls: ['./latest-checkout.component.scss'],
})
export class LatestCheckoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
