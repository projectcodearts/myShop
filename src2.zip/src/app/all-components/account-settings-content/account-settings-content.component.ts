import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-settings-content',
  templateUrl: './account-settings-content.component.html',
  styleUrls: ['./account-settings-content.component.scss'],
})
export class AccountSettingsContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
