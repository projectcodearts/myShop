import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oders-search',
  templateUrl: './oders-search.component.html',
  styleUrls: ['./oders-search.component.scss'],
})
export class OdersSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
