import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-content',
  templateUrl: './all-content.component.html',
  styleUrls: ['./all-content.component.scss'],
})
export class AllContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
