import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setup-profile-content',
  templateUrl: './setup-profile-content.component.html',
  styleUrls: ['./setup-profile-content.component.scss'],
})
export class SetupProfileContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
