import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shop-details-content',
  templateUrl: './shop-details-content.component.html',
  styleUrls: ['./shop-details-content.component.scss'],
})
export class ShopDetailsContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
