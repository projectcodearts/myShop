import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-details-content',
  templateUrl: './business-details-content.component.html',
  styleUrls: ['./business-details-content.component.scss'],
})
export class BusinessDetailsContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
