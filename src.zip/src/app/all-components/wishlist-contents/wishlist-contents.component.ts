import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wishlist-contents',
  templateUrl: './wishlist-contents.component.html',
  styleUrls: ['./wishlist-contents.component.scss'],
})
export class WishlistContentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
