import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-user-address-content',
  templateUrl: './select-user-address-content.component.html',
  styleUrls: ['./select-user-address-content.component.scss'],
})
export class SelectUserAddressContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
