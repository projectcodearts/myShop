import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-shop-ad',
  templateUrl: './new-shop-ad.component.html',
  styleUrls: ['./new-shop-ad.component.scss'],
})
export class NewShopAdComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
