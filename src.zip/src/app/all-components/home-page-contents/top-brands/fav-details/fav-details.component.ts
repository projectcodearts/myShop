import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fav-details',
  templateUrl: './fav-details.component.html',
  styleUrls: ['./fav-details.component.scss'],
})
export class FavDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
