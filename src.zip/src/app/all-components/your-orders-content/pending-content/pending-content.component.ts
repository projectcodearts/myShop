import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending-content',
  templateUrl: './pending-content.component.html',
  styleUrls: ['./pending-content.component.scss'],
})
export class PendingContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
