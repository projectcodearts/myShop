import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-account-security',
  templateUrl: './user-account-security.component.html',
  styleUrls: ['./user-account-security.component.scss'],
})
export class UserAccountSecurityComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
