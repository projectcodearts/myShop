import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-user-address',
  templateUrl: './select-user-address.page.html',
  styleUrls: ['./select-user-address.page.scss'],
})
export class SelectUserAddressPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
