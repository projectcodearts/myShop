import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-otp-register',
  templateUrl: './verify-otp-register.page.html',
  styleUrls: ['./verify-otp-register.page.scss'],
})
export class VerifyOtpRegisterPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
